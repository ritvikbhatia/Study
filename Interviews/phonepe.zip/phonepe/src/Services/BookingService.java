package Services;

import Models.Branch;
import Models.City;
import Models.Vehicle;
import Models.VehicleType;

import java.util.List;

public class BookingService implements BookingInterface {
    City city =City.getCity();
    @Override
    public Vehicle bookVehicle(VehicleType vehicleType,int start, int end) {
        List<Branch> branches=city.getBranches();
        for (Branch b:branches)
        {
            //logic to find min vehicle
        }
        return new Vehicle("123");
    }
}
