package Models;

public class Vehicle {
    private String id;

    int [] bookingTime;

    public Vehicle(String id) {
        this.id = id;
        this.bookingTime=new int[24];
    }




}
