package Models;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Branch {
    String name;
    HashMap<VehicleType, List<Vehicle>> vehicles;
    HashMap<VehicleType, Integer> prices;
    public void addPrice(VehicleType vehicleType,int price)
    {
        prices.put(vehicleType,price);
    }
    public void addVehicle(VehicleType vehicleType,Vehicle vehicle)
    {
        List<Vehicle> list=this.vehicles.get(vehicleType);
        list.add(vehicle);
        this.vehicles.put(vehicleType,list);
    }

    public Branch(String name) {
        this.name = name;
        this.vehicles= new HashMap<VehicleType, List<Vehicle>>();
        this.prices=new HashMap<>();
    }
}
